<script setup lang="ts">
import { ref } from "vue";

interface Todo {
  id: number;
  title: string;
  completed: boolean;
}

const todos = ref<Todo[]>([
  {
    id: 1,
    title: "Todo 1",
    completed: false,
  },
]);

const todoValue = ref("");

const addTodo = () => {
  const lastId = todos.value[todos.value.length - 1]?.id ?? 1;
  todos.value.push({
    id: lastId + 1,
    title: todoValue.value,
    completed: false,
  });
  todoValue.value = "";
};

const deleteTodo = (id: number) => {
  todos.value = todos.value.filter((todo) => todo.id !== id);
};

const markAsCompleted = (id: number) => {
  todos.value = todos.value.map((todo) => {
    if (todo.id === id) {
      todo.completed = !todo.completed;
    }
    return todo;
  });
};
</script>

<template>
  <div
    class="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 py-12 px-4 sm:px-6 lg:px-8"
  >
    <div class="max-w-2xl mx-auto">
      <!-- Header -->
      <div class="text-center mb-8">
        <h1 class="text-5xl font-bold text-white mb-2 drop-shadow-lg">
          ✨ Todo Uygulaması
        </h1>
        <p class="text-white/80 text-lg">
          Görevlerinizi modern bir şekilde yönetin
        </p>
      </div>

      <!-- Main Card -->
      <div
        class="bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl p-8 border border-white/20"
      >
        <!-- Input Section -->
        <div class="mb-8">
          <div class="relative">
            <input
              type="text"
              v-model="todoValue"
              @keypress.enter="addTodo"
              placeholder="Yeni görev ekle..."
              class="w-full px-6 py-4 bg-white/90 backdrop-blur-sm rounded-2xl border-2 border-transparent focus:border-white focus:outline-none focus:ring-4 focus:ring-white/30 transition-all duration-300 text-gray-800 placeholder-gray-400 text-lg shadow-lg"
            />
            <button
              @click="addTodo"
              class="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Ekle
            </button>
          </div>
        </div>

        <!-- Todo List -->
        <div class="space-y-3">
          <div
            v-for="todo in todos"
            :key="todo.id"
            class="group bg-white/90 backdrop-blur-sm rounded-2xl p-5 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-white/50"
          >
            <div class="flex items-center justify-between">
              <!-- Todo Title -->
              <div class="flex items-center flex-1 min-w-0">
                <button
                  @click="markAsCompleted(todo.id)"
                  class="flex-shrink-0 mr-4 w-6 h-6 rounded-full border-2 transition-all duration-300 flex items-center justify-center"
                  :class="
                    todo.completed
                      ? 'bg-gradient-to-r from-green-400 to-emerald-500 border-green-500'
                      : 'border-gray-300 hover:border-green-400'
                  "
                >
                  <svg
                    v-if="todo.completed"
                    class="w-4 h-4 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="3"
                      d="M5 13l4 4L19 7"
                    ></path>
                  </svg>
                </button>
                <span
                  class="text-lg font-medium transition-all duration-300 truncate"
                  :class="
                    todo.completed
                      ? 'text-gray-400 line-through'
                      : 'text-gray-800'
                  "
                >
                  {{ todo.title }}
                </span>
              </div>

              <!-- Action Buttons -->
              <div class="flex items-center gap-2 ml-4 flex-shrink-0">
                <button
                  @click="markAsCompleted(todo.id)"
                  class="px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-300 transform hover:scale-105"
                  :class="
                    todo.completed
                      ? 'bg-gradient-to-r from-amber-400 to-orange-500 text-white hover:from-amber-500 hover:to-orange-600 shadow-md'
                      : 'bg-gradient-to-r from-green-400 to-emerald-500 text-white hover:from-green-500 hover:to-emerald-600 shadow-md'
                  "
                >
                  {{ todo.completed ? "Geri Al" : "Tamamla" }}
                </button>
                <button
                  @click="deleteTodo(todo.id)"
                  class="px-4 py-2 bg-gradient-to-r from-red-500 to-rose-600 text-white rounded-xl hover:from-red-600 hover:to-rose-700 transition-all duration-300 text-sm font-semibold shadow-md transform hover:scale-105"
                >
                  Sil
                </button>
              </div>
            </div>
          </div>

          <!-- Empty State -->
          <div v-if="todos.length === 0" class="text-center py-12">
            <div class="text-6xl mb-4">📝</div>
            <p class="text-white/80 text-lg">Henüz görev eklemediniz</p>
            <p class="text-white/60">
              Yukarıdaki alandan yeni görev ekleyebilirsiniz
            </p>
          </div>
        </div>

        <!-- Stats -->
        <div class="mt-8 pt-6 border-t border-white/20">
          <div class="flex justify-between items-center text-white/90">
            <div class="text-center flex-1">
              <div class="text-3xl font-bold">{{ todos.length }}</div>
              <div class="text-sm text-white/70">Toplam</div>
            </div>
            <div class="text-center flex-1 border-l border-r border-white/20">
              <div class="text-3xl font-bold text-green-300">
                {{ todos.filter((t) => t.completed).length }}
              </div>
              <div class="text-sm text-white/70">Tamamlanan</div>
            </div>
            <div class="text-center flex-1">
              <div class="text-3xl font-bold text-amber-300">
                {{ todos.filter((t) => !t.completed).length }}
              </div>
              <div class="text-sm text-white/70">Bekleyen</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Debug Info (Optional - can be removed) -->
      <details
        class="mt-6 bg-black/20 backdrop-blur-sm rounded-2xl p-4 border border-white/10"
      >
        <summary
          class="text-white/80 cursor-pointer hover:text-white transition-colors font-semibold"
        >
          🔍 Debug Bilgisi (Geliştirici)
        </summary>
        <pre
          class="mt-4 text-white/70 text-sm overflow-auto bg-black/30 p-4 rounded-xl"
          >{{ todos }}</pre
        >
      </details>
    </div>
  </div>
</template>
